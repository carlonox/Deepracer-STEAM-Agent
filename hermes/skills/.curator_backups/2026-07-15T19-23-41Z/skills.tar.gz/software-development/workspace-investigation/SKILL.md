---
name: workspace-investigation
description: "Explore and understand workspace contents — directory structure, file discovery, Windows-WSL path resolution."
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [workspace, filesystem, exploration, navigation, investigation]
related_skills: [codebase-inspection, systematic-debugging]
---

# Workspace Investigation

## When to Use

- The user asks "what files do you see?" or "what's in this directory?"
- You need to understand the project structure before starting work
- The user provides a Windows path (`C:\...`) and you're in WSL/Linux
- A file isn't found at the expected location — need to trace mount points
- General "get oriented" before changing anything

## Principles

1. **Always get the full picture first** — partial listings lead to incorrect assumptions.
2. **Use the right tool for the job** — `search_files` is for content/file-name search, NOT for directory overviews.
3. **When a path doesn't resolve, trace the mount** — environment-specific mounts are common in WSL/Docker.

## Step 1: Directory Overview

When asked "what's in this directory?" or "what files do you see?":

```bash
# Top-level listing with types, sizes, dates — ALWAYS start here
ls -la /workspace/

# Full directory tree (max depth appropriate to project size)
find /workspace -maxdepth 2 -type d | sort

# If the project is large, limit depth
find /workspace -maxdepth 3 -type d | sort | head -40
```

**Why not `search_files`?** `search_files` with a generic pattern returns a truncated view (50 results by default) and may only show files in deep subdirectories while skipping the top-level layout. It's designed for content search and file matching, not for getting a complete directory listing. Use `terminal` with `ls -la` and `find` for that.

**Pro tip:** Run `ls -la /workspace/` AND `find /workspace -maxdepth 2 -type d | sort` together. The first shows files + sizes + permissions; the second reveals the folder tree. Reading both gives you the complete lay of the land — searching for one pattern can't replace it.

## Step 2: Understand the Mount Layout

When in WSL or Linux and the user provides a Windows path:

```bash
# Check where Windows drives are mounted
df -h

# Check mount details
mount | grep -E "^[A-Z]:|9p|drvfs|/mnt"

# Common patterns:
# - C:\ at /mnt/c/  (standard WSL)
# - C:\ at /workspace  (Docker/WSL with custom mount)
# - C:\ at /opt/data  (Hermes Docker container mapping)
```

**Signs the mount is non-standard:**
- `/mnt/c/Users/` doesn't exist
- `/workspace/` contains Windows project files at root level
- `df` shows a `9p` or `drvfs` filesystem on `/workspace`

**How to resolve user's Windows path:**
1. Check `df` to see where `C:\` is mounted
2. Translate `C:\Users\UNAL\Project\file.md` → `<mount_point>/Users/UNAL/Project/file.md`
3. If the mount is at `/workspace`, the path becomes `/workspace/Users/UNAL/Project/file.md`

## Step 3: File Discovery

Once oriented, dig into specific areas:

```bash
# Find files by name/type (terminal approach)
find /workspace -name "*.md" -maxdepth 3 2>/dev/null

# Find files by name (hermes tool — good for content search too)
search_files(pattern="*.md", target="files", path="/workspace")

# Find large files to understand project weight
du -sh /workspace/*/ | sort -rh | head -10
```

## Step 4: Project Documentation Discovery

When the user says "look at the documentation", "mira la documentación", or references docs you haven't seen yet:

```bash
# Find ALL documentation files in the project first
find /workspace -name "*.md" -maxdepth 4 \
  -not -path "*/node_modules/*" \
  -not -path "*/.git/*" \
  -not -path "*/hermes/*" \
  -not -path "*/backup/*" | sort

# Check common doc directories
ls /workspace/docs/ 2>/dev/null
ls /workspace/RAG/ 2>/dev/null

# README always first — then setup guides
read_file(path="/workspace/README.md")
```

**Don't assume one file tells the whole story.** A project may have:
- A migration/upgrade doc (`Documentacion.md`)
- A setup/operation guide (`GUIA_SETUP.md`, `docs/GUIA_SETUP.md`, `RAG/GUIA_SETUP.md`)
- An API reference (`backend/API.md`)
- Manuals in `RAG/` or `docs/`

Always survey before reading deeply. The file the user mentioned may be a migration or changelog, not the operational guide.

## Step 5: Content Reading

```bash
# Read files with line numbers
read_file(path="/workspace/file.md")

# Search content
search_files(pattern="important_function", path="/workspace/src/", file_glob="*.py")

# For multi-file discovery across docs, find all relevant files then read
find /workspace -name "GUIA_SETUP.md" -maxdepth 4 -not -path "*/node_modules/*" 2>/dev/null
```

## Pitfalls

1. **Don't trust `search_files` for directory overviews** — It's optimized for content matching, not exhaustive directory listing. Always use `ls -la` + `find` for the full picture.
2. **Don't assume `/mnt/c/` exists** — In Docker containers or custom WSL setups, `C:\` may be mounted directly at `/workspace` or another path. Always check `df`.
3. **`ls` without `-la` omits hidden files** — Use `ls -la` to see everything, including `.git`, `.env`, etc.
4. **`find` without `-maxdepth` can be slow** — On large projects, cap the depth. Start with depth 2-3.
5. **Windows paths are case-insensitive** — When translating from Windows to Linux, try both cases if the first attempt fails.
6. **Permission denied on some dirs** — Use `2>/dev/null` with `find` to skip inaccessible directories.
7. **A single doc file is not the documentation suite** — When the user says "mira la documentación", a migration doc (`Documentacion.md`) is not the same as an operational guide (`GUIA_SETUP.md`). Survey all `.md` files first, then read the ones most relevant to the user's current task. A changelog tells you what changed; a setup guide tells you how to operate it.
8. **Windows path → actual path isn't always a simple translation** — Even after resolving the mount point, the file may be at the project root rather than under `Users/<name>/...`. If `ls <translated_path>` fails, search by filename: `find <mount> -name "<filename>" -maxdepth 5 2>/dev/null`.
