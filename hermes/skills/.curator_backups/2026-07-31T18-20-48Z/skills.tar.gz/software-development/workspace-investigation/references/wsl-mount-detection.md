# WSL Windows Drive Mount Detection

## Scenario: User-provided Windows path doesn't resolve

When a user gives a `C:\Users\...\file.md` path and `/mnt/c/` doesn't exist, the mount is non-standard.

### Diagnostic Commands

```bash
# 1. Check where disks are mounted
df -h

# 2. Check mount type
mount | grep -E "^[A-Z]:|9p|drvfs"
```

### Observed Pattern (2026-07-07)

In this environment (Hermes Docker container on Docker Desktop, Windows 11):

```
Filesystem      Size  Used Avail Use% Mounted on
overlay        1007G  9.5G  947G   1% /
C:\             953G  244G  710G  26% /workspace
```

- `C:\` mounted at `/workspace` via `9p` (Plan 9 filesystem protocol)
- `aname=drvfs;path=C:\;` — Windows drive mounted through WSL's drvfs
- `/mnt/` directory exists but is **empty**
- No `/mnt/c/` — standard WSL mount is NOT present here

### Path Translation

Given `C:\Users\UNAL\Deepracer-STEAM-Agent\Documentacion.md`:
- Mount point: `/workspace` (from `df`)
- Translate: `C:\` → `/workspace`
- Result: `/workspace/Users/UNAL/Deepracer-STEAM-Agent/Documentacion.md`

But in the actual case, the project root WAS the workspace root, so the file was at `/workspace/Documentacion.md`. This means the user's project folder **is** the mount root.

### Why This Happens

Docker Desktop for Windows manages WSL mounts differently than bare WSL. When a Docker container has `volumes: - ./:/workspace`, the Windows project directory becomes the container's `/workspace` directly.
